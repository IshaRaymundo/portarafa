// import React, { } from "react";



// function IndexDashboard() {
//   return (
    
//   <div>
//     <h1>Hola</h1>
//   </div> 
    
//   );
// }

// export default IndexDashboard;
