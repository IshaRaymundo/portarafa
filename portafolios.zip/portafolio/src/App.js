import './App.css';
import React from "react"

// import CondicionalAtmosferica from './Pages-Dash/CondicionalAtmosferica';
// import Login from './componentes/Login';
// import CocktailDatabase from './paginas/CocktailDatabase';
import CocktailRandom from './paginas/CocktailRandom';
import Tours from './paginas/Tours';

function App() {
  return (
    <>
      {/* <CondicionalAtmosferica/> */}
      {/* <CocktailRandom/> */}
      <Tours/>
      {/* <CocktailDatabase /> */}
      {/* <Login/> */}
    </>
  );
}

export default App;
