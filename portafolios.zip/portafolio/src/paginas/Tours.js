import React from "react"
import { dbFirebase } from "../bd/firebaseConfig"

function Tours(){
    const [nombre,setNombre]=useState("")
    const [descripcion,setDescripcion]=useState("")
    const [precio,setPrecio]=useState(0)

    return(
        <>
        <form>
            <input type="text"  placeholder="Nombre">
                onChange={(e)=>setNombre(e.target.value)}</input>
            <input type="text"  placeholder="Descripcion">
                onChange={(e)=>setDescripcion(e.target.value)}</input>
            <input type="number"  placeholder="Precio">
                onChange={(e)=>setPrecio(e.target.value)}</input>
            <button type="submit">Guardar Tour</button>
        </form>
        </>
    )
}

export default Tours